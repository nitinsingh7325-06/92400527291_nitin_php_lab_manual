// script.js – login logic (stays on page) + animated lavender tree (canvas)

document.addEventListener('DOMContentLoaded', function () {
    // ---------- CANVAS: ANIMATED LAVENDER TREE ----------
    const canvas = document.getElementById('treeCanvas');
    const ctx = canvas.getContext('2d');
  
    let width, height;
  
    function resizeCanvas() {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    }
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();
  
    // tree parameters
    const treeColor = '#b89ab0';     // lavender / soft purple
    const leafColor = '#c9aac2';     // lighter lavender
    const trunkColor = '#7a5a70';
  
    let time = 0;
  
    // recursive tree drawing (simple fractal)
    function drawTree(x, y, len, angle, depth, maxDepth) {
      if (depth > maxDepth || len < 2) return;
  
      // compute end point
      const endX = x + len * Math.cos(angle);
      const endY = y - len * Math.sin(angle);
  
      // trunk / branch color
      const isLeaf = depth >= maxDepth - 1;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(endX, endY);
      ctx.lineWidth = isLeaf ? 2.5 : Math.max(2, len / 8);
      ctx.strokeStyle = isLeaf ? leafColor : trunkColor;
      ctx.shadowColor = 'rgba(180, 140, 170, 0.3)';
      ctx.shadowBlur = 8;
      ctx.stroke();
      ctx.shadowBlur = 0;
  
      // randomize branches with slight animation
      const angleOffset = 0.35 + 0.08 * Math.sin(time * 0.5 + depth * 0.7);
      const lenFactor = 0.72 + 0.04 * Math.sin(time * 0.3 + depth);
  
      // left branch
      drawTree(endX, endY, len * lenFactor, angle - angleOffset, depth + 1, maxDepth);
      // right branch
      drawTree(endX, endY, len * lenFactor, angle + angleOffset, depth + 1, maxDepth);
  
      // extra tiny branch for fullness (lavender)
      if (depth > 2 && depth % 2 === 0) {
        const smallAngle = angle + 0.5 * (depth % 3 === 0 ? 1 : -1);
        drawTree(endX, endY, len * 0.45, smallAngle, depth + 2, maxDepth);
      }
    }
  
    // draw a full tree with gentle wind animation
    function drawFullTree() {
      ctx.clearRect(0, 0, width, height);
  
      // background gradient (lavender sky)
      const grad = ctx.createLinearGradient(0, 0, 0, height);
      grad.addColorStop(0, '#e8d5e0');
      grad.addColorStop(0.6, '#d4bfcf');
      grad.addColorStop(1, '#c5aebb');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);
  
      // subtle ground shadow
      ctx.fillStyle = 'rgba(160, 130, 150, 0.15)';
      ctx.beginPath();
      ctx.ellipse(width * 0.5, height * 0.92, width * 0.5, 40, 0, 0, Math.PI * 2);
      ctx.fill();
  
      // draw tree – position depends on screen size
      const baseX = width * 0.5;
      const baseY = height * 0.88;
      const trunkLen = Math.min(width, height) * 0.22 + 10;
      const maxDepth = 7;
  
      // slight sway animation
      const sway = 0.03 * Math.sin(time * 0.4);
      drawTree(baseX, baseY, trunkLen, Math.PI / 2 + sway, 0, maxDepth);
  
      // add extra floating lavender particles (leaves / blossoms)
      for (let i = 0; i < 18; i++) {
        const angleOffset = Math.random() * Math.PI * 2;
        const radius = 60 + Math.random() * 180;
        const px = baseX + radius * Math.cos(angleOffset + time * 0.1 * (i % 3 + 1));
        const py = baseY - 50 - radius * 0.35 * Math.sin(angleOffset + time * 0.15 * (i % 2 + 1)) - 30;
        ctx.beginPath();
        ctx.arc(px, py, 2 + Math.random() * 4, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(200, 170, 195, ${0.3 + 0.2 * Math.sin(time + i)})`;
        ctx.shadowColor = 'rgba(180, 140, 170, 0.2)';
        ctx.shadowBlur = 12;
        ctx.fill();
      }
      ctx.shadowBlur = 0;
  
      // draw some small floating lavender dots
      for (let i = 0; i < 30; i++) {
        const x = (i * 137 + 50) % width;
        const y = (i * 97 + 30) % height;
        const size = 1.5 + Math.sin(i + time * 0.5) * 1.2;
        ctx.beginPath();
        ctx.arc(x, y, size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(190, 160, 180, ${0.15 + 0.1 * Math.sin(time * 0.7 + i)})`;
        ctx.fill();
      }
    }
  
    // animation loop
    function animateTree() {
      time += 0.03;
      drawFullTree();
      requestAnimationFrame(animateTree);
    }
    animateTree();
  
    // ---------- LOGIN FORM LOGIC (STAYS ON PAGE, NO REDIRECT) ----------
    const form = document.getElementById('loginForm');
    const emailInput = document.getElementById('loginEmail');
    const passwordInput = document.getElementById('loginPassword');
    const togglePasswordBtn = document.getElementById('togglePasswordBtn');
    const passwordEyeIcon = document.getElementById('passwordEyeIcon');
    const loginStatus = document.getElementById('loginStatus');
  
    // toggle password visibility
    togglePasswordBtn.addEventListener('click', function () {
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      if (type === 'text') {
        passwordEyeIcon.classList.remove('fa-eye');
        passwordEyeIcon.classList.add('fa-eye-slash');
      } else {
        passwordEyeIcon.classList.remove('fa-eye-slash');
        passwordEyeIcon.classList.add('fa-eye');
      }
    });
  
    // client-side validation + feedback (stays on page)
    function validateAndShowStatus(email, password) {
      loginStatus.textContent = '';
      loginStatus.className = '';
  
      const emailTrim = email.trim();
      if (emailTrim === '') {
        loginStatus.textContent = '⚠️ Email/username is required.';
        loginStatus.className = 'error';
        return false;
      }
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (emailTrim.includes('@') && !emailPattern.test(emailTrim)) {
        loginStatus.textContent = '⚠️ Please enter a valid email address.';
        loginStatus.className = 'error';
        return false;
      }
  
      if (password.length < 4) {
        loginStatus.textContent = '⚠️ Password must be at least 4 characters.';
        loginStatus.className = 'error';
        return false;
      }
  
      // ✅ SUCCESS – stays on page, shows success message, no redirect
      loginStatus.textContent = '✅ Login successful! Welcome back.';
      loginStatus.className = 'success';
      return true;
    }
  
    // form submit – PREVENTS redirect, stays on page
    form.addEventListener('submit', function (event) {
      event.preventDefault(); // 🔥 CRITICAL: prevents page reload/redirect
  
      const email = emailInput.value;
      const password = passwordInput.value;
      const isValid = validateAndShowStatus(email, password);
  
      if (!isValid) {
        // shake animation on error
        form.style.animation = 'shake 0.2s ease-in-out';
        setTimeout(() => { form.style.animation = ''; }, 300);
      } else {
        // Optional: you could add a subtle celebration effect here
        // The success message is already shown in validateAndShowStatus
        console.log('✅ Login successful – user stays on this page.');
      }
    });
  
    // clear status on input (only if it's an error or success message)
    emailInput.addEventListener('input', function () {
      if (loginStatus.className === 'error' || loginStatus.className === 'success') {
        loginStatus.textContent = '';
        loginStatus.className = '';
      }
    });
    passwordInput.addEventListener('input', function () {
      if (loginStatus.className === 'error' || loginStatus.className === 'success') {
        loginStatus.textContent = '';
        loginStatus.className = '';
      }
    });
  
    // inject shake keyframes
    const styleShake = document.createElement('style');
    styleShake.textContent = `
      @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-8px); }
        75% { transform: translateX(8px); }
      }
    `;
    document.head.appendChild(styleShake);
  
    // hint message (demo credentials)
    const hint = document.createElement('div');
    hint.style.cssText = `
      text-align: center; font-size: 0.8rem; color: #6a4e62; margin: 0.6rem 0 -0.2rem 0;
      background: rgba(255,240,245,0.3); padding: 0.2rem; border-radius: 40px;
      transition: opacity 0.6s;
    `;
    hint.textContent = '⚡ demo credentials pre-filled (email + pass)';
    const signupDiv = document.querySelector('.signup-text');
    form.insertBefore(hint, signupDiv);
    setTimeout(() => {
      hint.style.opacity = '0';
      setTimeout(() => { if (hint.parentNode) hint.remove(); }, 700);
    }, 4500);
  });